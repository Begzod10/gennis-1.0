from flask import Flask, jsonify, request, render_template, session, json, send_file, send_from_directory
from flask_wtf import FlaskForm
from flask_wtf.file import FileField, FileRequired
from backend.school.models import custom_migrate, register_commands
from flask_cors import CORS
from flask_jwt_extended import JWTManager
from backend.models.models import *
from flask_restful import Api

app = Flask(__name__, static_folder="frontend/build", static_url_path="/")

CORS(app, resources={r"/api/*": {"origins": "*"}})

app.config.from_object('backend.models.config')
db = db_setup(app)
apis = Api(app)

migrate = Migrate(app, db)
jwt = JWTManager(app)
register_commands(app)

# classroom_server = "http://192.168.1.15:5001"

classroom_server = "https://classroom.gennis.uz"
# telegram_bot_server = "http://127.0.0.1:5000"
django_server = "https://school.gennis.uz"
# django_server = "http://192.168.1.14:7622"

# test block
from backend.student.register_for_tes.resources import *

# filters
from backend.functions.filters import *

# account folder
from backend.account.payment import *
from backend.account.account import *
from backend.account.overhead_capital import *
from backend.account.salary import *
from backend.account.test_acc import *

# functions folder
from backend.functions.checks import *
from backend.functions.small_info import *

# QR code
from backend.QR_code.qr_code import *

# routes
from backend.routes.views import *

# student
from backend.student.views import *

# programmers
from backend.for_programmers.for_programmers import *

# teacher
from backend.teacher.views import *

# group
from backend.group.create_group import *
from backend.group.view import *
from backend.group.change import *
from backend.group.test import *

# time_table
from backend.time_table.view import *
from backend.time_table.room import *

# home
from backend.home_page.route import *
# certificate
from backend.certificate.views import *
# get api
from backend.routes.get_api import *

# classroom
from backend.class_room.views import *

# bot
from backend.telegram_bot.route import *

# book
from backend.book.main import *

# lead
from backend.lead.views import *

# mobile
from backend.mobile.views import *

# tasks
from backend.tasks.admin.views import *

# investment
from backend.account.profile.investment import *

# buxgalter
from backend.account.profile.views import *

# from backend.account.debit_credit.views import *

from backend.account.debit_credit.views import *

from backend.school.views import *

# teacher observation, attendance, teacher_group_statistics
if __name__ == '__main__':
    app.run()
