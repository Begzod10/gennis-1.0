# account_sid = 'ACd83d8ba1a4de6633d47c6bdba9b6e9d5'
# auth_token = 'cdd4068b52217ba9ececefce0924c451'
#
# sms_payment = "Gennis info"

# number = "+998993656845"
