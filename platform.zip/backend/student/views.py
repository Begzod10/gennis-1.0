from .platform.payments import *
from .platform.change import *
from backend.student.student_functions import *
from backend.student.change_student import *
from backend.student.calling_to_students import *
