from backend.tasks.teacher.debt_tasks.routes.views import *

from backend.tasks.teacher.attendance_tasks.routes.views import *

from backend.tasks.teacher.lesson_plan.routes.views import *
from backend.tasks.teacher.lesson_plan.routes.select_groups import *
